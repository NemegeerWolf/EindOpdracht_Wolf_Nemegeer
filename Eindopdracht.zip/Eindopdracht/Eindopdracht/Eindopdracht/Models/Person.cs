﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Eindopdracht.Models
{
    public class Person
    {
        public string Name { get; set; }
        public string Birth_year { get; set; }
        public string Death_year { get; set; }

    }
}
